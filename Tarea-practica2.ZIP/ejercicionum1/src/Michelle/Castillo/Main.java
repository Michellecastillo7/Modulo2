/*
 * Crear el código que imprima la siguiente salida: "Hola, soy Arnol Gutiérrez" (Usar su nombre
 */
package Michelle.Castillo;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hola, soy Michel Castillo");
    }
}